### How to use this super-secure method to access Gmail, FB


1. Install https://tunnelblick.net/release/Tunnelblick_3.7.0_build_4790.dmg

2. When installation finish, double click on the file `nurhaci.opvn`. Tunnelblick (installed above) will install the rest. It may ask for administrative password (type your computer password).

3. Double click on Tunnelblick icon in `Application` folder to launch the private connection. Once Tunnelblick has been launched, there will be a Tunnelblick icon in the menu bar at the top right of the screen for controlling connections. Click on the icon, and then the Connect menu item to initiate the VPN connection. Select the `Nurhaci` connection.
